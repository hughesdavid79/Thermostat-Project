/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// UART Global Variables
char output[64];
int bytesToSend;
UART_Handle uart;

// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }  // TMP006 sensor at address 0x41
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;
I2C_Handle i2c;

// Temperature and Set-point variables
float currentTemp = 25.0;  // Default current temperature (to be updated)
float setPointTemp = 22.0; // Default set-point temperature
int heaterStatus = 0;      // Heater status: 0 = off, 1 = on
uint32_t secondsElapsed = 0;

// Timer and Button variables
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;
volatile unsigned char buttonPressed = 0;
volatile unsigned long lastButtonPressTime = 0;  // To store the last button press time

// Second Button Variables
volatile unsigned char secondButtonPressed = 0;

// Function Prototypes
void initUART(void);
void initI2C(void);
void initTimer(void);
void readTemperature(void);
void scanI2C(void);
void timerCallback(Timer_Handle myHandle, int_fast16_t status);
void gpioButtonFxn0(uint_least8_t index);  // Button 1 Callback
void gpioButtonFxn1(uint_least8_t index);  // Button 2 Callback
void updateLED(void);
void reportStatus(void);

#define DISPLAY(x) UART_write(uart, &output, x);

// UART Initialization
void initUART(void) {
    UART_Params uartParams;

    UART_init();  // Init UART driver

    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    uart = UART_open(CONFIG_UART_0, &uartParams);
    if (uart == NULL) {
        while (1);  // UART_open() failed
    }
}

// I2C Initialization (called once at the start)
void initI2C(void) {
    I2C_Params i2cParams;

    DISPLAY(snprintf(output, 64, "\rInitializing I2C Driver - "));  // Added \r for cleaner alignment

    I2C_init();  // Init I2C driver

    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL) {
        DISPLAY(snprintf(output, 64, "\rFailed\n\r"));  // Added \r for cleaner alignment
        while (1);
    }

    DISPLAY(snprintf(output, 32, "\rPassed\n\r"));  // Added \r for cleaner alignment
}

// Function to read temperature without reinitializing I2C
void readTemperature(void) {
    i2cTransaction.slaveAddress = sensors[2].address;  // TMP006 address
    txBuffer[0] = sensors[2].resultReg;  // TMP006 result register

    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 2;  // Reading 2 bytes (e.g., temperature data)

    if (I2C_transfer(i2c, &i2cTransaction)) {
        DISPLAY(snprintf(output, 64, "\rTMP006 sensor detected at 0x41\n"));  // Added \r for cleaner alignment

        // Example: Converting and displaying temperature reading (14-bit)
        int16_t rawTemp = (rxBuffer[0] << 8) | rxBuffer[1];  // Combine the two bytes
        rawTemp >>= 2;  // Adjust for the 14-bit resolution of TMP006

        currentTemp = rawTemp * 0.03125;  // Convert to Celsius
        DISPLAY(snprintf(output, 64, "\rTemperature: %.2f �C\n", currentTemp));  // Added \r for cleaner alignment
    } else {
        DISPLAY(snprintf(output, 64, "\rFailed to communicate with TMP006 sensor at 0x41\n"));  // Added \r for cleaner alignment
    }
}

// Timer Initialization
void initTimer(void) {
    Timer_Params params;

    Timer_init();  // Init Timer driver

    Timer_Params_init(&params);
    params.period = 500000;  // 500ms period
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        while (1);  // Timer_open() failed
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        while (1);  // Timer_start() failed
    }
}

// Timer callback function
void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    TimerFlag = 1;  // Set the flag every 500ms
    secondsElapsed += 1;  // Increment elapsed seconds every 500ms
}

// Button Press Callback with Debounce (Button 1)
void gpioButtonFxn0(uint_least8_t index) {
    unsigned long currentTime = Timer_getCount(timer0);  // Get current time

    // Debounce: Only register the button press if 200ms have passed
    if (currentTime - lastButtonPressTime > 200000) {  // 200ms debounce
        buttonPressed = 1;  // Set flag to indicate the button was pressed
        lastButtonPressTime = currentTime;  // Update last press time
    }
}

// Second Button Callback (Button 2)
void gpioButtonFxn1(uint_least8_t index) {
    secondButtonPressed = 1;  // Set flag for second button
}

// Update LED status based on current temperature and set-point
void updateLED(void) {
    if (currentTemp < setPointTemp) {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Heater ON
        heaterStatus = 1;
    } else {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);  // Heater OFF
        heaterStatus = 0;
    }
}

// Report the current system status via UART
void reportStatus(void) {
    DISPLAY(snprintf(output, 64, "\r<%02d,%02d,%d,%04d>\n\n",  // Added extra \n for spacing
            (int)currentTemp, (int)setPointTemp, heaterStatus, secondsElapsed / 2));  // Reporting every second
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0) {
    GPIO_init();  // Initialize GPIO

    // Initialize peripherals
    initUART();
    initI2C();  // Initialize I2C once at startup
    initTimer();

    // Configure the LED and button pins
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);  // Second Button

    // Turn on user LED
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    // Install Button callback for both buttons
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);  // Second Button Callback

    // Enable interrupts for both buttons
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);  // Enable interrupt for second button

    while (1) {
        if (TimerFlag) {
            TimerFlag = 0;  // Reset the timer flag

            // Read the temperature every 500ms
            readTemperature();  // Call the temperature reading function

            // Update LED based on heater status
            updateLED();

            // Report system status every second
            if (secondsElapsed % 2 == 0) {
                reportStatus();  // Report system every 1 second
            }
        }

        // Handle button press to adjust set-point (Button 1)
        if (buttonPressed) {
            setPointTemp += 1.0;  // Increase the set-point temperature by 1�C
            DISPLAY(snprintf(output, 64, "\rSet-point increased to: %.2f �C\n\n", setPointTemp));  // Added extra \n for spacing
            buttonPressed = 0;  // Reset the button flag
        }

        // Handle second button press (Button 2)
        if (secondButtonPressed) {
            setPointTemp -= 1.0;  // Decrease the set-point temperature by 1�C
            DISPLAY(snprintf(output, 64, "\rSet-point decreased to: %.2f �C\n\n", setPointTemp));  // Added extra \n for spacing
            secondButtonPressed = 0;  // Reset second button flag
        }
    }
}
